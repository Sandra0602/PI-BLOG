<?php 
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
	print "<script>window.location='index.php';</script>";
}
//$user=$_SESSION["user_id"];
include 'conexion/conexion.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="img_fem/logo_unigen.png" type="">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <title>UNIGEN</title>
</head>
<body>
    <!---------Barra de arriba---------->
    <?php
        include'menu.php';
    ?>
    <section class="zona1"></section>

    <!--letras que cambian de color-->
    <div class="header-content container"> 
        <h1>UNIGEN</h1>

        <p> 
            A escala mundial, lograr la igualdad 
            de género también requiere la eliminación 
            de prácticas dañinas contra las mujeres y 
            las niñas, que incluyen el tráfico sexual, 
            el feminicidio, la violencia sexual durante 
            la guerra entre otras prácticas de violencia 
            contra la mujer.
        </p>


     </div> 

    <!--------Quienes Somos----------->
    <section class="general-blog3">
        <div class="general-blog1">
            <h2>¿Quiénes somos?</h2>
            <p>
                Nosotros somos una asociacion dirigida a la 
                concientizacion sobre la igualdad de genero. 
                Estamos enfocados a informar sobre situaciones 
                de riesgo que existen y brechas de gran problema 
                que esto ha causado.
            </p>
        </div>
    </section>

    <!----------Noticias-------------->
     
    <main class="services">

        <div class="services-content container">
            <h2>Noticias</h2>
            <button class="boton">Noticia 8 de Marzo
                <p class="n1">Lorem ipsum dolor sit amet consectetur, 
                                adipisicing elit.. Sit, voluptates.</p>
            </button>
            <div class="panel">
                <p class="nota">Leer noticia completa sobre el día 8 de Marzo.</p>
                <a href="noticia1.php" class="enlace-boton">Más sobre la noticia</a>
              </div>

                <button class="boton">Noticia 8 de Marzo
                    <p class="n1">Lorem ipsum dolor sit amet consectetur, 
                                    adipisicing elit.. Sit, voluptates.</p>
                </button>
                <div class="panel">
                    <p class="nota">Leer noticia completa sobre el día 8 de Marzo.</p>
                    <a href="noticia2.php" class="enlace-boton">Más sobre la noticia</a>
                  </div>

                <button class="boton">Noticia 8 de Marzo
                    <p class="n1">Lorem ipsum dolor sit amet consectetur, 
                                    adipisicing elit.. Sit, voluptates.</p>
                </button>
                <div class="panel">
                    <p class="nota">Leer noticia completa sobre el día 8 de Marzo.</p>
                    <a href="noticia3.php" class="enlace-boton">Más sobre la noticia</a>
                  </div>

            </div>   
    </main>

 <!--------------Blog--------------->
<section class="blog-container">
    <h2>Blog</h2>
    <p>Conseguir que exista igualdad de género 
        no es una tarea imposible, pero requiere 
        de la implicación de toda la ciudadanía.</p>

    <div class="blog-content">
        <div class="blog-1">
            <img src="img_fem/img_blog1.jpg" alt="">
            <h3>Post 1</h3>
            <p>La camita hacia la libertad. Únete a la marcha 8M</p>
        </div>

        <div class="blog-1">
            <img src="img_fem/img_blog2.jpg" alt="">
            <h3>Post 2</h3>
            <p>Nunca es tarde para alzar la voz, para defendernos.</p>
            <a href="publicaciones.php" class="btn-1"> Ver mas</a>
        </div>

        <div class="blog-1">
            <img src="img_fem/img_blog3.jpg" alt="">
            <h3>Post 3</h3>
            <p>Moving the thoughts</p>
        </div>
    </div>
</section>


    <!---Cuales son algunas formas...--->
    <section class="general-blog">
        <div class="general-blog1">
            <h2>¿Cuáles son algunas formas en las que 
                se manifiesta la violencia de género?</h2>
            <p>
                Como la violencia doméstica, el acoso 
                sexual, la trata de personas con fines 
                de explotación sexual, el matrimonio 
                forzado, entre otros.
            </p>
            <a href="#" class="btn-1"> Informacion</a>
        </div>
         <div class="general-blog2"> </div>
    
    </section>

    <div class="general-blog"> </div>

    <!--Situación de la mujer-->

    <section class="Genero">

        <div class="Genero-content container">

            <h2>Situacion de la mujer</h2>
                <p class="txt-p"> 
                    Existen 7 ámbitos de desigualdad 
                    donde la mujer se ve en desventaja 
                    debido a las condiciones sociales 
                    o las políticas públicas de los 
                    distintos países. 
                </p>

                <div class="genero-group"> 

                    <div class="generos">
                     <img src="img_fem/img_equi.jpg" alt="">
                     <h3>Diferencia entre igualdad y 
                          equidad de género </h3> 
                     <p>
                        En este sentido, la equidad de 
                        género se encaminará principalmente 
                        a brindar oportunidades justas a 
                        todas las personas independientemente 
                        de su género.
                     </p>
                </div>

                <div class="generos"> 
                    <img src="img_fem/img_mij.jpg" alt="">
                    <h3>Importancia de la igualdad de género 
                        en el desarrollo sostenible </h3> 
                    <p>
                        Las mujeres y las niñas representan 
                        la mitad de la población mundial y 
                        también, por tanto, la mitad de su 
                        potencial.
                    </p>
               </div>

               <div class="generos"> 
                <img src="img_fem/img_marcha.png" alt="">
                <h3>Importancia de la igualdad de género 
                    en el desarrollo sostenible </h3> 
                <p>
                    Las mujeres y las niñas representan 
                    la mitad de la población mundial y 
                    también, por tanto, la mitad de su 
                    potencial.
                </p>
           </div>
         </div>

        </div>

    </section>


    
    <!-----------footer------------->
    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Informacion-blog</h3>
                
                <ul>
                    <li> <a href="#">Fecha </a></li>
                    <li> <a href="#">Fecha </a></li>
                    <li> <a href="#">Fecha </a></li>
                    <li> <a href="#">Fecha </a></li>
                </ul>

            </div>
            <div class="link">
                <h3>Informacion-blog1</h3>
                
                <ul>
                    <li> <a href="#">Publico </a></li>
                    <li> <a href="#">Publico </a></li>
                    <li> <a href="#">Publico </a></li>
                    <li> <a href="#">Publico </a></li>
                </ul>

            </div>
            <div class="link">
                <h3>Informacion-blog3</h3>     
                <ul>
                    <li> <a href="#">Visitante </a></li>
                    <li> <a href="#">Visitante </a></li>
                    <li> <a href="#">Visitante </a></li>
                    <li> <a href="#">Visitante </a></li>
                </ul>
            </div>
            <div class="link">
                <h3>Informacion-blog2</h3>              
                <ul>
                    <li> <a href="#">Privado </a></li>
                    <li> <a href="#">Privado </a></li>
                    <li> <a href="#">Privado </a></li>
                    <li> <a href="#">Privado </a></li>
                </ul>
            </div>

        </div>

    </footer>
   
    <script src="script.js"></script>
    <script src="bot.js"></script>
</body>
</html>