<?php 
session_start();

//$user=$_SESSION["user_id"];
include 'conexion/conexion.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="img_fem/logo_unigen.png" type="">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unigen</title>
    <link rel="stylesheet" href="style3.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <?php
        include'menu.php';
    ?>

    <!------------------publicacion 1------------------->
    <div class="container2">

        <div class="segundo-bloque">
            <?php
                $sql="select t1.fecha,t1.contenido,t1.titulo, t2.imagen from publicaciones t1 JOIN imagenes t2 ON t2.id_publicaciones=t1.id order by fecha DESC";
                $res = $db->execute($sql);
                while ($r=$res->fetch_array()) {
                    
            ?>
            <div class="post-container">
                <div class="post-row">
                    <div class="user-profile">
                        <img src="img_fem/img_comu.jpg">
                        <div>
                            <p>Unigen</p>
                            <span><?php echo date("d/m/Y H:i",strtotime($r["fecha"]))?></span>
                        </div>
                    </div>

                    </a>
                </div>
                <h1><?php echo $r["titulo"]?> </h1>
                    <p class="post-text"><?php echo $r["contenido"]?> </p>
                        <?php
                            echo '<img class="post-img" src="data:image/jpeg;base64,'.base64_encode($r["imagen"]).'"/>'; 
                        ?>
                    <div class="post-row">

                        <!--
                        <div class="activity-icons">
                            <div><img src="images-3/like-blue.png">120</div>
                            <div><img src="images-3/comments.png">25</div>
                            <div><img src="images-3/share.png">9</div>
                        </div>
                        <div class="post-profile-icon">
                            <img src="images-3/profile-pic.png"><i class='bx bxs-chevron-down'></i>
                        </div>
                        -->
                    </div>
            </div>
            <?php
                }
            ?>
           
    

            
        </div>
    </div>
</div> 


<div class="footer">
    <p>Copyright 2024 - UNIGEN &copy;</p>
</div>

<script src="script3.js"></script>
</body>
</html>