<?php require_once "./views/parte_superior.php"?>

    <!--Inicio del contenido principal-->
        <div class="container border">
            <h1 class="fs-1">PAGINA DE BUTTONS</h1>
        </div>

<?php require_once "./views/parte_inferior.php"?>