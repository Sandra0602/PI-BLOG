$(document).ready(function(){
    var tablaPersonas = $("#tablaPersonas").DataTable({
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast":"Último",
                "sNext":"Siguiente",
                "sPrevious": "Anterior"
            },
            "sProcessing":"Procesando...",
        }
    });
    
    $("#btnNuevo").click(function(){
        $("#formPublicacion").trigger("reset"); // Cambiar al id del formulario
        $(".modal-title").text("Nueva Publicación"); // Cambiar el título
        $("#modalCRUD").modal("show");
        id=null;
        opcion = 1; //alta
    });
    
    var fila; //capturar la fila para editar o borrar el registro
    
    //botón EDITAR
    $(document).on("click", ".btnEditar", function(){
        fila = $(this).closest("tr");
        id = parseInt(fila.find('td:eq(0)').text());
        contenido = fila.find('td:eq(1)').text(); // Cambiar contenido
        titulo = fila.find('td:eq(2)').text(); // Cambiar titulo
        fecha = fila.find('td:eq(3)').text(); // Cambiar fecha
        nombre = fila.find('td:eq(4)').text(); // Cambiar nombre
        
        $("#contenido").val(contenido); // Cambiar contenido
        $("#titulo").val(titulo); // Cambiar titulo
        $("#fecha").val(fecha); // Cambiar fecha
        $("#nombre").val(nombre); // Cambiar nombre
        
        opcion = 2; //editar
        
        $(".modal-title").text("Editar Publicación"); // Cambiar título
        $("#modalCRUD").modal("show");
    });

    //botón BORRAR
    $(document).on("click", ".btnBorrar", function(){    
        console.log("Botón Editar clickeado");
        fila = $(this).closest("tr");
        var id = parseInt(fila.find('td:eq(0)').text());
        var opcion = 3; // borrar
        var respuesta = confirm("¿Está seguro de eliminar el registro: " + id + "?");
        if(respuesta){
            $.ajax({
                url: "bd/crud.php",
                type: "POST",
                dataType: "json",
                data: {opcion:opcion, id:id},
                success: function(){
                    tablaPersonas.row(fila).remove().draw(); // Remover la fila de la tabla
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }   
    });
    
    // Submit del formulario para guardar/editar
    $("#formPublicacion").submit(function(e){
        e.preventDefault();
        
        contenido = $.trim($("#contenido").val()); // Cambiar contenido
        titulo = $.trim($("#titulo").val()); // Cambiar titulo
        fecha = $.trim($("#fecha").val()); // Cambiar fecha
        nombre = $.trim($("#nombre").val()); // Cambiar nombre
        
        $.ajax({
            url: "bd/crud.php",
            type: "POST",
            dataType: "json",
            data: {id:id, contenido:contenido, titulo:titulo, fecha:fecha, nombre:nombre, opcion:opcion},
            success: function(data){
                console.log(data);
                id = data.id;
                if(opcion == 1){ // Alta
                    tablaPersonas.row.add([id, contenido, titulo, fecha, nombre]).draw(); // Agregar nueva fila
                } else { // Editar
                    tablaPersonas.row(fila).data([id, contenido, titulo, fecha, nombre]).draw(); // Actualizar fila existente
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
        $("#modalCRUD").modal("hide");
    });
});


